"use client";

import React, { useRef } from "react";
import { ACHIEVEMENTS } from "@/lib/data";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { Reveal } from "@/components/ui/Reveal";
import { Trophy, ChevronLeft, ChevronRight, Award } from "lucide-react";

export function Achievements() {
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  const scrollBy = (offset: number) => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollBy({ left: offset, behavior: "smooth" });
    }
  };

  return (
    <section
      id="achievements"
      aria-label="Milestones and Achievements"
      className="py-24 sm:py-32 px-4 sm:px-6 max-w-7xl mx-auto border-t border-black/5"
    >
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 sm:mb-12">
        <Reveal>
          <SectionHeading
            number="06"
            eyebrow="Milestones & Recognition"
            title="Recognitions &"
            italicWord="achievements."
            subtitle="Verified participations, innovation challenge triumphs, and community service honors."
            className="mb-0"
          />
        </Reveal>

        {/* Desktop Horizontal Scroll Controls */}
        <div className="hidden lg:flex items-center gap-2 mt-4 md:mt-0">
          <button
            type="button"
            onClick={() => scrollBy(-380)}
            className="w-10 h-10 rounded-full border border-black/15 bg-white hover:bg-[#E9E6E0] text-[#0D0D0D] flex items-center justify-center transition-colors active:scale-95 cursor-pointer"
            aria-label="Scroll achievements left"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <button
            type="button"
            onClick={() => scrollBy(380)}
            className="w-10 h-10 rounded-full border border-black/15 bg-white hover:bg-[#E9E6E0] text-[#0D0D0D] flex items-center justify-center transition-colors active:scale-95 cursor-pointer"
            aria-label="Scroll achievements right"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Horizontal Scroll Gallery on Desktop, Stacked Cards on Mobile */}
      <div
        ref={scrollContainerRef}
        className="flex flex-col lg:flex-row gap-6 lg:overflow-x-auto lg:pb-6 lg:snap-x lg:snap-mandatory no-scrollbar"
      >
        {ACHIEVEMENTS.map((item, index) => (
          <div
            key={item.number}
            className="w-full lg:w-[380px] lg:shrink-0 lg:snap-start"
          >
            <Reveal delayMs={index * 100}>
              <div className="h-full bg-white/80 hover:bg-white p-7 sm:p-8 rounded-2xl border border-black/8 hover:border-black/20 transition-all duration-300 shadow-2xs hover:shadow-md flex flex-col justify-between">
                <div>
                  {/* Top Bar with Number & Year */}
                  <div className="flex items-center justify-between pb-4 border-b border-black/8">
                    <span className="font-mono text-2xl font-black text-[#0D0D0D]/20">
                      {item.number}
                    </span>
                    <span className="font-mono text-xs font-semibold px-2.5 py-0.5 rounded bg-[#F4F2EE] text-[#0D0D0D] border border-black/5">
                      {item.year}
                    </span>
                  </div>

                  {/* Context Badge */}
                  <div className="mt-5 mb-2">
                    <span className="text-[11px] font-mono uppercase tracking-wider text-[#77756F] block">
                      {item.roleOrContext}
                    </span>
                    <h3 className="text-lg sm:text-xl font-bold text-[#0D0D0D] tracking-tight mt-1 leading-snug">
                      {item.title}
                    </h3>
                  </div>

                  {/* Issuer */}
                  <p className="text-xs font-medium text-[#77756F]">
                    {item.issuer}
                  </p>

                  {/* Description */}
                  <p className="mt-4 text-xs sm:text-sm text-[#3A3A3A] leading-relaxed font-normal">
                    {item.description}
                  </p>
                </div>

                {/* Highlight Stats Pill */}
                {item.stats && (
                  <div className="mt-6 pt-4 border-t border-black/8 flex items-center gap-2">
                    <Award className="w-4 h-4 text-[#0D0D0D] shrink-0" />
                    <span className="text-xs font-mono font-medium text-[#0D0D0D]">
                      {item.stats}
                    </span>
                  </div>
                )}
              </div>
            </Reveal>
          </div>
        ))}
      </div>
    </section>
  );
}
